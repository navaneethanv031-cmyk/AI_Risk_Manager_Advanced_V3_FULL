
from pydantic import BaseModel, Field

class OrderInput(BaseModel):
    order_amount: float = Field(gt=0)
    previous_orders: int = Field(ge=1)
    previous_returns: int = Field(ge=0)
    account_age_days: int = Field(ge=1)
    delivery_distance_km: float = Field(ge=0)
    cod: int = Field(ge=0, le=1)
    high_value_category: int = Field(ge=0, le=1)
    address_changes: int = Field(ge=0)
    support_contacts: int = Field(ge=0)
    coupon_usage_rate: float = Field(ge=0, le=1)

class PredictionResponse(BaseModel):
    risk_score: float
    risk_level: str
    recommendation: str
    key_factors: list[str]
