
from pathlib import Path
import joblib,pandas as pd
BASE=Path(__file__).resolve().parents[1]
A=joblib.load(BASE/"models"/"return_risk_model.joblib")
MODEL,FEATURES,THRESHOLD=A["model"],A["features"],A["threshold"]

def predict(payload):
    x=payload.model_dump() if hasattr(payload,"model_dump") else payload.copy()
    x["return_rate"]=x["previous_returns"]/x["previous_orders"] if x["previous_orders"] else 0
    X=pd.DataFrame([[x[f] for f in FEATURES]],columns=FEATURES)
    score=float(MODEL.predict_proba(X)[0,1])
    level="HIGH" if score>=.75 else ("MEDIUM" if score>=.45 else "LOW")
    rec={"HIGH":"Manual verification before fulfillment",
         "MEDIUM":"Route to enhanced review",
         "LOW":"Normal processing"}[level]
    factors=[]
    if x["previous_returns"]/x["previous_orders"]>=.35:factors.append("High historical return rate")
    if x["account_age_days"]<45:factors.append("New customer account")
    if x["order_amount"]>=15000:factors.append("High order value")
    if x["cod"]:factors.append("Cash-on-delivery payment")
    if x["address_changes"]>=2:factors.append("Multiple address changes")
    if x["delivery_distance_km"]>=30:factors.append("Long delivery distance")
    if x["coupon_usage_rate"]>=.65:factors.append("Heavy coupon usage")
    return {"risk_score":round(score,4),"risk_level":level,"recommendation":rec,"key_factors":factors[:6] or ["No dominant heuristic risk factor"]}

def metrics():
    import json
    return json.loads((BASE/"models"/"metrics.json").read_text())
