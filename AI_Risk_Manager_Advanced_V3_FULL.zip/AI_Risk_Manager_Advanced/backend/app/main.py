
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .schemas import OrderInput,PredictionResponse
from .predictor import predict,metrics
app=FastAPI(title="AI Risk Manager",version="3.0.0",description="Defense-only return-risk intelligence API.")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
@app.get("/")
def root(): return {"message":"AI Risk Manager API running","version":"3.0.0"}
@app.get("/health")
def health(): return {"status":"healthy"}
@app.post("/predict",response_model=PredictionResponse)
def prediction(order:OrderInput): return predict(order)
@app.get("/metrics")
def get_metrics(): return metrics()
@app.get("/model-info")
def model_info(): return metrics()["model"]
