
from pathlib import Path
import json, joblib
import pandas as pd
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score, average_precision_score

BASE=Path(__file__).resolve().parent
train=pd.read_csv(BASE/"data/train.csv")
val=pd.read_csv(BASE/"data/validation.csv")
test=pd.read_csv(BASE/"data/test.csv")

FEATURES=[
"order_amount","previous_orders","previous_returns","account_age_days",
"delivery_distance_km","cod","high_value_category","address_changes",
"support_contacts","coupon_usage_rate","return_rate"
]
model=Pipeline([
("scale",StandardScaler()),
("clf",HistGradientBoostingClassifier(
    max_depth=6,learning_rate=.05,max_iter=350,
    min_samples_leaf=12,l2_regularization=.4,random_state=42))
])
model.fit(train[FEATURES],train["returned"])

FP_COST=50
FN_COST=1200
vp=model.predict_proba(val[FEATURES])[:,1]
best=None
for t in np.arange(.15,.81,.01):
    pred=(vp>=t).astype(int)
    tn,fp,fn,tp=confusion_matrix(val["returned"],pred).ravel()
    cost=fp*FP_COST+fn*FN_COST
    if best is None or cost<best["cost"]:
        best={"threshold":float(round(t,2)),"cost":int(cost)}
threshold=best["threshold"]

prob=model.predict_proba(test[FEATURES])[:,1]
pred=(prob>=threshold).astype(int)
tn,fp,fn,tp=confusion_matrix(test["returned"],pred).ravel()
metrics={
"dataset":{"train_rows":len(train),"validation_rows":len(val),"held_out_test_rows":len(test),
           "positive_rate_test":round(float(test["returned"].mean()),4)},
"model":{"name":"HistGradientBoostingClassifier","threshold_selected_on":"validation_set",
         "threshold":threshold,"features":FEATURES},
"precision":round(float(precision_score(test["returned"],pred,zero_division=0)),4),
"recall":round(float(recall_score(test["returned"],pred,zero_division=0)),4),
"f1":round(float(f1_score(test["returned"],pred,zero_division=0)),4),
"roc_auc":round(float(roc_auc_score(test["returned"],prob)),4),
"average_precision":round(float(average_precision_score(test["returned"],prob)),4),
"confusion_matrix":{"tn":int(tn),"fp":int(fp),"fn":int(fn),"tp":int(tp)},
"cost_assumptions":{"false_positive_review_cost_inr":FP_COST,"false_negative_loss_inr":FN_COST},
"costs":{"false_positive_cost_inr":int(fp*FP_COST),"false_negative_cost_inr":int(fn*FN_COST),
         "total_error_cost_inr":int(fp*FP_COST+fn*FN_COST)},
"risk_buckets":{"low":int((prob<.45).sum()),
                "medium":int(((prob>=.45)&(prob<.75)).sum()),
                "high":int((prob>=.75).sum())}
}
(BASE/"models"/"metrics.json").write_text(json.dumps(metrics,indent=2))
joblib.dump({"model":model,"features":FEATURES,"threshold":threshold},BASE/"models"/"return_risk_model.joblib")
print(json.dumps(metrics,indent=2))
