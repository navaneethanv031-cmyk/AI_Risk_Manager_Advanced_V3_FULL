# AI Risk Manager — Advanced v2

A defense-only merchant risk operations prototype for **return-risk detection**.

## What is advanced here?
- ML detector using HistGradientBoosting.
- Separate train / validation / held-out test datasets.
- Decision threshold selected on validation data using explicit INR error costs.
- Held-out metrics are reported only after the model is fixed.
- Explainable risk factors for human review.
- FastAPI production-style API with health/model-info/metrics endpoints.
- Risk Operations Center dashboard.
- KPI cards, confusion matrix, risk distribution, business-cost panel, governance panel.
- Input validation prevents impossible demo cases such as returns > previous orders.
- Human-in-the-loop recommendations; the system does not automatically reject customers.

## Run
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python train_model.py
uvicorn app.main:app --reload
```

Open:
- Swagger: http://127.0.0.1:8000/docs
- Dashboard: open `frontend/index.html`

## Evaluation design
- Train: 3,600
- Validation: 800
- Held-out test: 600
- Threshold selection happens on validation only.
- Test metrics are calculated once on the held-out set.
- FP review cost: ₹50
- FN missed-risk loss: ₹1,200

## Defense-only scope
The project only predicts merchant return risk and recommends human review. It contains no offensive, fraud-generation, credential, evasion, or attack functionality.

## Production caveat
The included dataset is synthetic for a competition prototype. Real deployment needs merchant-provided data, temporal validation, calibration, privacy/security controls, monitoring, drift detection, audit logs and approved human-review policy.
